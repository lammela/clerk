package org.clerk.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = DataRow.class)
public class DataRowDataOnDemand {
}
