package org.clerk.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = DataRow.class)
public class DataRowIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
